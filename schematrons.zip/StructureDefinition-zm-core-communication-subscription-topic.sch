<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile SubscriptionTopic
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:SubscriptionTopic</sch:title>
    <sch:rule context="f:SubscriptionTopic">
      <sch:assert test="count(f:name) &gt;= 1">name: minimum cardinality of 'name' is 1</sch:assert>
      <sch:assert test="count(f:title) &gt;= 1">title: minimum cardinality of 'title' is 1</sch:assert>
      <sch:assert test="count(f:description) &gt;= 1">description: minimum cardinality of 'description' is 1</sch:assert>
      <sch:assert test="count(f:resourceTrigger) &gt;= 1">resourceTrigger: minimum cardinality of 'resourceTrigger' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:SubscriptionTopic/f:resourceTrigger</sch:title>
    <sch:rule context="f:SubscriptionTopic/f:resourceTrigger">
      <sch:assert test="count(f:supportedInteraction) &gt;= 1">supportedInteraction: minimum cardinality of 'supportedInteraction' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
