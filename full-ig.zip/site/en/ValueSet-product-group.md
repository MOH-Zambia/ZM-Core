# Zambia eLMIS Product Group ValueSet - HL7 FHIR Implementation Guide: ZM-Core Release 1 - Zambia v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Zambia eLMIS Product Group ValueSet**

## ValueSet: Zambia eLMIS Product Group ValueSet 

| | |
| :--- | :--- |
| *Official URL*:http://hapi.moh.gov.zm/fhir/ValueSet/product-group | *Version*:0.2.0 |
| Draft as of 2026-10-21 | *Computable Name*:ZMProductGroupVS |

 
Allowed Product Group values from the eLMIS Master list. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "product-group",
  "url" : "http://hapi.moh.gov.zm/fhir/ValueSet/product-group",
  "version" : "0.2.0",
  "name" : "ZMProductGroupVS",
  "title" : "Zambia eLMIS Product Group ValueSet",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-10-21T04:21:07+00:00",
  "publisher" : "Ministry of Health - Zambia",
  "contact" : [{
    "name" : "Ministry of Health - Zambia",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.moh.gov.zm/"
    },
    {
      "system" : "email",
      "value" : "digital.health@moh.gov.zm"
    }]
  },
  {
    "name" : "ZM-Core Team",
    "telecom" : [{
      "system" : "email",
      "value" : "zm-core@moh.gov.zm",
      "use" : "work"
    }]
  }],
  "description" : "Allowed Product Group values from the eLMIS Master list.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "ZM",
      "display" : "Zambia"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://hapi.moh.gov.zm/fhir/CodeSystem/product-group"
    }]
  }
}

```
