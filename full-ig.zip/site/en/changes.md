# Changes - HL7 FHIR Implementation Guide: ZM-Core Release 1 - Zambia v0.2.0

* [**Table of Contents**](toc.md)
* **Changes**

## Changes

 This provides a list of changes to the MyIG specification since its initial release 

 **2099-01-01 v0.1.0 - My IG R1 (STU ballot 1) Ballot Candidate** based on FHIR R4 

* Initial version

